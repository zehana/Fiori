# Chapter-4-5-6-CDS-ABAP-backend-code
This Repository contains all the backend code (CDS, ABAP) for the apps developed in the SAP Press book **ABAP Development for SAP S/4HANA - ABAP Programming Model for SAP Fiori** written by Stefan Haas, Bince Mathew.

The package content has been exported using abapGit: https://docs.abapgit.org/.

Guide to import an offline project into a SAP system using abapGit: https://docs.abapgit.org/guide-import-zip.html.
